import game

game.app.run(host='0.0.0.0', port=4567)
